﻿using PatternRecognition.FingerprintRecognition.Core;
using PatternRecognition.FingerprintRecognition.FeatureExtractors;
using System;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml.Serialization;

namespace POC
{
    public partial class MainForm : Form {
        private List<Minutia> Features;

        public MainForm( ) {
            InitializeComponent( );
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Browse_Click( object sender, EventArgs e ) {
            OpenFileDialog.FileName = string.Empty;
            if( OpenFileDialog.ShowDialog( ) == DialogResult.OK ) {
                //
                // Processing a new file so reset the UI.
                //
                ResetUI( );
                //
                // Capture and display the path and image (fingerprint) for the selected file.
                //
                ImagePath.Text = OpenFileDialog.FileName;
                FingerImage.Load( ImagePath.Text );
                //
                // Enable the appropriate controls.
                //
                Reset.Enabled = true;
                Analyze.Enabled = true;
                ImagePath.Enabled = true;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Analyze_Click( object sender, EventArgs e ) {
            try {
                //
                // Analysis may take a few seconds so display the wait cursor.
                // Try/finally ensures that the cursor is reset.
                //
                Cursor = Cursors.WaitCursor;
                //
                // Create an Extractor and extract the minutia from the image.
                //
                var MinutiaeExtractor = new Ratha1995MinutiaeExtractor( );
                Features = MinutiaeExtractor.ExtractFeatures( new Bitmap( FingerImage.Image ) );
                //
                // Display all of the minutia in a grid.
                //
                FeatureGridView.DataSource = Features;
                //
                // Enable the appropriate controls.
                //
                Save.Enabled = true;
                FtpPath.Enabled = true;
            } finally {
                //
                // Reset the cursor.
                //
                Cursor = Cursors.Default;
            }
        }
        /// <summary>
        /// Reset controls to their initial state.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ResetButton_Click( object sender, EventArgs e ) {
            ResetUI( );
        }
        /// <summary>
        /// 
        /// </summary>
        private void ResetUI(
            ) {
            ImagePath.Text = string.Empty;
            ImagePath.Enabled = false;
            FtpPath.Text = string.Empty;
            FtpPath.Enabled = false;
            FingerImage.Image = null;
            FeatureGridView.DataSource = null;
            Reset.Enabled = false;
            Analyze.Enabled = false;
            Save.Enabled = false;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Save_Click( object sender, EventArgs e ) {
            //
            // Prepare and display the path (same as image file but with "ftp" extension)
            // to the "ftp" file.
            //
            FtpPath.Text = Path.ChangeExtension( ImagePath.Text, @"ftp" );
            FtpPath.Enabled = true;
            //
            // Stream the Features to the "ftp" file. 
            //
            XmlSerializer Serializer = new XmlSerializer( Features.GetType( ) );
            FileStream FtpFS = new FileStream( FtpPath.Text, FileMode.Create );
            Serializer.Serialize( FtpFS, Features );
            FtpFS.Close( );
        }
        /// <summary>
        /// Quick and dirty "About" dialog to help identify the version, etc.
        /// of Identity.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AboutButton_Click( object sender, EventArgs e ) {
            StringBuilder About = new StringBuilder( );
            About.AppendLine( Application.CompanyName );
            About.AppendLine( Application.ProductVersion );
            MessageBox.Show(
                About.ToString( ),
                Application.ProductName,
                MessageBoxButtons.OK,
                MessageBoxIcon.Information
                );
        }
    }
}