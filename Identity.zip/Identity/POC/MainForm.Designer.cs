﻿namespace POC
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.label1 = new System.Windows.Forms.Label();
            this.ImagePath = new System.Windows.Forms.TextBox();
            this.Browse = new System.Windows.Forms.Button();
            this.OpenFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.FingerImage = new System.Windows.Forms.PictureBox();
            this.FeatureGridView = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.FtpPath = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Analyze = new System.Windows.Forms.Button();
            this.Save = new System.Windows.Forms.Button();
            this.Reset = new System.Windows.Forms.Button();
            this.About = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.FingerImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.FeatureGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Enabled = false;
            this.label1.Location = new System.Drawing.Point(20, 27);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "Image Path:";
            // 
            // ImagePath
            // 
            this.ImagePath.Enabled = false;
            this.ImagePath.Location = new System.Drawing.Point(20, 49);
            this.ImagePath.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ImagePath.Name = "ImagePath";
            this.ImagePath.ReadOnly = true;
            this.ImagePath.Size = new System.Drawing.Size(656, 22);
            this.ImagePath.TabIndex = 4;
            // 
            // Browse
            // 
            this.Browse.Location = new System.Drawing.Point(699, 46);
            this.Browse.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Browse.Name = "Browse";
            this.Browse.Size = new System.Drawing.Size(39, 28);
            this.Browse.TabIndex = 0;
            this.Browse.Text = "...";
            this.Browse.UseVisualStyleBackColor = true;
            this.Browse.Click += new System.EventHandler(this.Browse_Click);
            // 
            // OpenFileDialog
            // 
            this.OpenFileDialog.Filter = "TIFF files|*.tif";
            this.OpenFileDialog.ReadOnlyChecked = true;
            // 
            // FingerImage
            // 
            this.FingerImage.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.FingerImage.Enabled = false;
            this.FingerImage.Location = new System.Drawing.Point(16, 147);
            this.FingerImage.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.FingerImage.Name = "FingerImage";
            this.FingerImage.Size = new System.Drawing.Size(660, 372);
            this.FingerImage.TabIndex = 3;
            this.FingerImage.TabStop = false;
            // 
            // FeatureGridView
            // 
            this.FeatureGridView.AllowUserToAddRows = false;
            this.FeatureGridView.AllowUserToDeleteRows = false;
            this.FeatureGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.FeatureGridView.Enabled = false;
            this.FeatureGridView.Location = new System.Drawing.Point(699, 147);
            this.FeatureGridView.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.FeatureGridView.Name = "FeatureGridView";
            this.FeatureGridView.ReadOnly = true;
            this.FeatureGridView.Size = new System.Drawing.Size(724, 372);
            this.FeatureGridView.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Enabled = false;
            this.label2.Location = new System.Drawing.Point(17, 125);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 17);
            this.label2.TabIndex = 7;
            this.label2.Text = "Image:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Enabled = false;
            this.label3.Location = new System.Drawing.Point(696, 126);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 17);
            this.label3.TabIndex = 8;
            this.label3.Text = "Minutia:";
            // 
            // FtpPath
            // 
            this.FtpPath.Enabled = false;
            this.FtpPath.Location = new System.Drawing.Point(20, 98);
            this.FtpPath.Margin = new System.Windows.Forms.Padding(4);
            this.FtpPath.Name = "FtpPath";
            this.FtpPath.ReadOnly = true;
            this.FtpPath.Size = new System.Drawing.Size(656, 22);
            this.FtpPath.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Enabled = false;
            this.label4.Location = new System.Drawing.Point(20, 76);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(176, 17);
            this.label4.TabIndex = 5;
            this.label4.Text = "Fingerprint Template Path:";
            // 
            // Analyze
            // 
            this.Analyze.Enabled = false;
            this.Analyze.Location = new System.Drawing.Point(309, 545);
            this.Analyze.Name = "Analyze";
            this.Analyze.Size = new System.Drawing.Size(75, 23);
            this.Analyze.TabIndex = 1;
            this.Analyze.Text = "Analy&ze";
            this.Analyze.UseVisualStyleBackColor = true;
            this.Analyze.Click += new System.EventHandler(this.Analyze_Click);
            // 
            // Save
            // 
            this.Save.Enabled = false;
            this.Save.Location = new System.Drawing.Point(1024, 545);
            this.Save.Name = "Save";
            this.Save.Size = new System.Drawing.Size(75, 23);
            this.Save.TabIndex = 2;
            this.Save.Text = "&Save";
            this.Save.UseVisualStyleBackColor = true;
            this.Save.Click += new System.EventHandler(this.Save_Click);
            // 
            // Reset
            // 
            this.Reset.Enabled = false;
            this.Reset.Location = new System.Drawing.Point(770, 49);
            this.Reset.Name = "Reset";
            this.Reset.Size = new System.Drawing.Size(75, 23);
            this.Reset.TabIndex = 1;
            this.Reset.Text = "Reset";
            this.Reset.UseVisualStyleBackColor = true;
            this.Reset.Click += new System.EventHandler(this.ResetButton_Click);
            // 
            // About
            // 
            this.About.Location = new System.Drawing.Point(877, 49);
            this.About.Name = "About";
            this.About.Size = new System.Drawing.Size(75, 23);
            this.About.TabIndex = 10;
            this.About.Text = "&About...";
            this.About.UseVisualStyleBackColor = true;
            this.About.Click += new System.EventHandler(this.AboutButton_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1452, 597);
            this.Controls.Add(this.About);
            this.Controls.Add(this.Reset);
            this.Controls.Add(this.Save);
            this.Controls.Add(this.Analyze);
            this.Controls.Add(this.FtpPath);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.FeatureGridView);
            this.Controls.Add(this.FingerImage);
            this.Controls.Add(this.Browse);
            this.Controls.Add(this.ImagePath);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "MainForm";
            this.Text = "Identity";
            ((System.ComponentModel.ISupportInitialize)(this.FingerImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.FeatureGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox ImagePath;
        private System.Windows.Forms.Button Browse;
        private System.Windows.Forms.OpenFileDialog OpenFileDialog;
        private System.Windows.Forms.PictureBox FingerImage;
        private System.Windows.Forms.DataGridView FeatureGridView;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox FtpPath;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button Analyze;
        private System.Windows.Forms.Button Save;
        private System.Windows.Forms.Button Reset;
        private System.Windows.Forms.Button About;
    }
}

